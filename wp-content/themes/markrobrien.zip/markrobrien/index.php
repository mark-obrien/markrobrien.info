<?php get_header(); ?>

<section class="splash">
		
			<div class="container">
			
				<div class="row">
				
					<div class="logo">
			
						<h1 class="animated bounceInLeft">Mark R O'Brien</h1>
						<h2 class="greeting animated bounceInRight">portfolio & blog</h2>

					</div>
				
				</div>
			
			</div>
		
		</section>
		
		<?php get_template_part('template-parts/home-about'); ?>
		
		<?php get_template_part('template-parts/home-gigs'); ?>

                <?php get_template_part('template-parts/testimonials'); ?>
		
		<?php get_template_part('template-parts/home-blog'); ?>

<?php get_footer(); ?>