<section id="blog" class="blog">
		
			<header>
			
				<h1>BLOG</h1>
			
			</header>
    
            <div class="container">  
            
            <?php
            $args = array('post_type' => 'post', 'posts_per_page' => 6, 'offset' => 1,);
            $the_query = new WP_Query( $args );
            
            $i = 1;
            //added before to ensure it gets opened
            echo '<div class="row" >'; ?>
            
            <?php if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
						
			<div class="col-md-6 inner-grey" > 

                <figure>
                
                <?php if ( has_post_thumbnail()) {
                    
                    $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full');
                    
                    echo '<a class="enlarge" href="' . $large_image_url[0] . '" title="' . the_title_attribute('echo=0') . '" data-fancy="gal" >';
                    
                    the_post_thumbnail('full');
                    
                    echo '</a>';
                    
                } ?>
                
                </figure>
                
                <h3><?php the_title(); ?></h3>
                
                <?php the_excerpt(); ?>
                
                
            </div><!-- /.col-md-2 work -->

            <?php // if multiple of 3 close div and open a new div
                 if($i % 2 == 0) {echo '</div><div class="row" >';}
            	 
            $i++;
            	 
            endwhile;
            
            endif;
            
            echo '</div>';
            
            
            // Reset Post Data
            wp_reset_postdata();
             
            ?>
            
            </div>
		
		</div>
						
			</div> <!-- /.col-md-12 -->
				
		</div> <!-- /.row -->
			
	</div> <!-- /.container -->

</section><!-- /#blog -->
