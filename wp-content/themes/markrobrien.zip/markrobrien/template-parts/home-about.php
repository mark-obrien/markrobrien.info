<section id ="about" class="about">
			
			<header>
			
				<h1>ABOUT</h1>
			
			</header>
			
			<div class="container">
			
				<div class="row">
				
					<div class="col-sm-4">
					
						<img src="<?php echo get_template_directory_uri(); ?>/assets/img/me.png" alt="Cartoon image of me">
					
					</div>
					
					<div class="col-sm-8 inner-grey">
					
						<p>I'm Mark, a front-end web developer from Minneapolis, MN. In January of 2010 I took my first HTML class and immediately fell in love with it. After graduating, I made the transition to a full-time freelancer.</p>

						<p>
						If you'd like me to work in-house for a specific length of time, I am more than willing to travel to almost anywhere in the world. Either way, If you have a project you need help with, contact me below.
						</p>
						
						<h3>HTML</h3>
						<div class="progress">
							<div class="progress-bar" role="progressbar" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100" style="width: 95%;"></div>
						</div>
						
						<h3>CSS</h3>
						<div class="progress">
							<div class="progress-bar" role="progressbar" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100" style="width: 95%;"></div>
						</div>
						
						<h3>WordPress</h3>
						<div class="progress">
							<div class="progress-bar" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%;"></div>
						</div>
						
						<h3>PHP</h3>
						<div class="progress">
							<div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;"></div>
						</div>
						
						<h3>jQuery</h3>
						<div class="progress">
							<div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;"></div>
						</div>		
						
					</div>
					
				
				</div>
				
				<div class="row">
				
					
				
			</div>
			
			</div>
		
		</section>