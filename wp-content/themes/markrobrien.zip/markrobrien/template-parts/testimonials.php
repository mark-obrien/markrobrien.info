<section id="testimonials">

        <div class="container">
            <div class="row">

                <div id="testimonials-slider" class="carousel slide">
                   
                    <div class="carousel-inner">
                    
                        <div class="active item">

                            <div class="col-md-2 col-md-offset-1">
                                
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/testimonial-top-hat.png" alt="airplane animation">

                            </div>

                            <div class="col-md-8">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus blandit nisi lectus, a porttitor nisi tincidunt facilisis</p>
                                <cite>John Doe, <span>website.com</span></cite>
                            </div>

                        </div>

                        <div class="item">

                            <div class="col-md-2 col-md-offset-1">

                                <div class="quote-icon">
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/testimonial-hank.png" alt="airplane animation">
                                </div>
                            </div>

                            <div class="col-md-8">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus blandit nisi lectus, a porttitor nisi tincidunt facilisis</p>
                                <cite>John Doe, <span>website.com</span></cite>
                            </div>

                        </div>

                       <div class="item">

                            <div class="col-md-2 col-md-offset-1">

                                <div class="quote-icon">
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/testimonial-chick.png" alt="airplane animation">
                                </div>
                            </div>

                            <div class="col-md-8">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus blandit nisi lectus, a porttitor nisi tincidunt facilisis</p>
                                <cite>John Doe, <span>website.com</span></cite>
                            </div>

                        </div>

                        <div class="item">

                            <div class="col-md-2 col-md-offset-1">

                                <div class="quote-icon">
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/wj.png" alt="airplane animation">
                                </div>
                            </div>

                            <div class="col-md-8">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus blandit nisi lectus, a porttitor nisi tincidunt facilisis</p>
                                <cite>John Doe, <span>website.com</span></cite>
                            </div>

                        </div>

                    </div>
                    
                    <!-- Carousel navigation arrows -->
                    <a class="carousel-control left" href="#testimonials-slider" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
                    <a class="carousel-control right" href="#testimonials-slider" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
                </div>
              
            </div><!-- /row -->
        </div><!-- /container -->

    </section>